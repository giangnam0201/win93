Deutsch
========

Um die Logos zu installieren, sollte man zuerst die
alten sichern (falls einem die neuen nicht gefallen!).

also:

Im Windows - Verzeichnis (meistens C:\Windows) die Dateien
LOGOS.SYS und LOGOW.SYS am besten in
LOGOS.OLD und LOGOW.OLD umbenennen.
Im Stammverzeichnis (c:\) LOGO.SYS (falls vorhanden) in
LOGO.OLD �ndern.

Dann die neuen Files ins Windows-Verzeichnis [ LOGOW.SYS und LOGOS.SYS ]
bzw. ins Boot-Verzeichnis(c:\) [ LOGO.SYS ] kopieren.
Fertig!
Zum Austesten einfach "Windows neu starten" anklicken!
(BEENDEN)
Uebrigens kann ein jeder sich die Bilder selber �ndern:
Einfach mit Paint um�ndern!
Dabei mu� aber die Gr��e bzw. der Farbmodus erhalten bleiben.
(am besten die Bilder uebermalen!)


ENGLISH
=======

If you don�t want to loose the old LOGOx.SYS - Files, you
should rename the files :
They are located in the main - Windows - directory
(for example : c:\Windows)

LOGOW.SYS ---> LOGOW.OLD
LOGOS.SYS ---> LOGOS.OLD

the LOGO.SYS file has to be in the boot-directory (e.g. c:\)
if there already exists a LOGO.SYS - file, rename it!

LOGO.SYS ---> LOGO.OLD

Now you can copy the new files into the Windows-/boot-directory.
If you�ve done this, just try to view the new startup-/shutdown-logos: 
Click on Shutdown / restart and watch!

NOTE!
You can change those files yourself, if you want to:
just open PAINT and then open the LOGOx.SYS-files.
But don�t change the size or convert them to other 
colour-modes!
The files must be saved as 256-colour pictures.

(c) 1997 Carsten Bolte. Kiel. DepecheCBI@aol.com. 
http://members.aol.com/depechecbi. KRAFTWERK and KLING KLANG. 
registered Trademarks of Ralf H�tter and Florian Schneider. 
http://www.kraftwerk.com. MoToRschaden Produkt 1997.